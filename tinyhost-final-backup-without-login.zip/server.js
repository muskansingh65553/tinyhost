const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

const MAIN_DOMAIN = 'visual-html-editor.online';
const CLOUDFLARE_ZONE_ID = 'd15ed27d46aaa4797882a7c5f948188c';
const CLOUDFLARE_EMAIL = 'Kashyapkumbhani18@gmail.com';
const CLOUDFLARE_API_KEY = '89a8296454cd257be609d326c7d673c5e735f';
const CLOUDFLARE_ACCOUNT_ID = '217f6f87437d3b5067efae8c720b84bc';

// Word lists for generating subdomains
const prefixes = ['my', 'our', 'the', 'cool', 'best', 'top'];
const words = ['site', 'page', 'app', 'code', 'web', 'hub', 'lab', 'dock', 'spot', 'zone', 'dev'];
const suffixes = ['pro', 'hub', 'lab', 'plus', 'dev'];

// Generate a random subdomain
function generateSubdomain() {
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const word = words[Math.floor(Math.random() * words.length)];
    const useSuffix = Math.random() > 0.5;
    const suffix = useSuffix ? suffixes[Math.floor(Math.random() * suffixes.length)] : '';
    
    return `${prefix}${word}${suffix}`.toLowerCase();
}

// Create CNAME record using Cloudflare API
async function createCNAMERecord(subdomain, pagesUrl) {
    try {
        console.log(`Creating CNAME record for ${subdomain}.${MAIN_DOMAIN} -> ${pagesUrl}`);
        const response = await fetch(
            `https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Auth-Email': CLOUDFLARE_EMAIL,
                    'X-Auth-Key': CLOUDFLARE_API_KEY
                },
                body: JSON.stringify({
                    type: 'CNAME',
                    name: `${subdomain}.${MAIN_DOMAIN}`,
                    content: pagesUrl,
                    proxied: false,
                    ttl: 1
                })
            }
        );

        const data = await response.json();
        console.log('CNAME creation response:', data);
        
        if (!data.success) {
            console.error('Failed to create CNAME record:', data.errors);
            throw new Error(`Failed to create CNAME record: ${data.errors?.[0]?.message || 'Unknown error'}`);
        }
        return data;
    } catch (error) {
        console.error('Error creating CNAME record:', error);
        throw error;
    }
}

// Attach custom domain to Pages project
async function attachCustomDomain(projectName, domain) {
    try {
        console.log(`Attaching custom domain ${domain} to project ${projectName}`);
        const response = await fetch(
            `https://api.cloudflare.com/client/v4/accounts/${CLOUDFLARE_ACCOUNT_ID}/pages/projects/${projectName}/domains`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Auth-Email': CLOUDFLARE_EMAIL,
                    'X-Auth-Key': CLOUDFLARE_API_KEY
                },
                body: JSON.stringify({
                    name: domain
                })
            }
        );

        const data = await response.json();
        console.log('Custom domain attachment response:', data);
        
        if (!data.success) {
            console.error('Failed to attach custom domain:', data.errors);
            throw new Error(`Failed to attach custom domain: ${data.errors?.[0]?.message || 'Unknown error'}`);
        }
        return data;
    } catch (error) {
        console.error('Error attaching custom domain:', error);
        throw error;
    }
}

// Create wrangler.toml configuration
function createWranglerConfig(subdomain) {
    const config = `
name = "${subdomain}"
compatibility_date = "2024-01-01"

routes = [
  { pattern = "${subdomain}.${MAIN_DOMAIN}", custom_domain = true }
]
`;
    return config;
}

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(process.cwd(), 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, `site-${Date.now()}.zip`);
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/zip' || file.mimetype === 'application/x-zip-compressed') {
            cb(null, true);
        } else {
            cb(new Error('Only ZIP files are allowed!'), false);
        }
    }
});

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

// Helper function to execute commands
async function executeCommand(command, cwd = process.cwd()) {
    console.log(`Executing command: ${command}`);
    const { stdout, stderr } = await execPromise(command, { cwd });
    if (stderr) console.error('Command stderr:', stderr);
    console.log('Command stdout:', stdout);
    return { stdout, stderr };
}

// Routes
app.get('/', (req, res) => {
    res.render('index');
});

app.post('/deploy', upload.single('zipFile'), async (req, res) => {
    let extractPath;
    let deployPath;
    try {
        if (!req.file) {
            throw new Error('No file uploaded');
        }

        const subdomain = generateSubdomain();
        const projectName = `site-${Date.now()}`;
        const zipFilePath = req.file.path;
        extractPath = path.join(process.cwd(), 'uploads', projectName, 'extract');
        deployPath = path.join(process.cwd(), 'uploads', projectName, 'deploy');

        // Create directories
        if (!fs.existsSync(extractPath)) {
            fs.mkdirSync(extractPath, { recursive: true });
        }
        if (!fs.existsSync(deployPath)) {
            fs.mkdirSync(deployPath, { recursive: true });
        }

        // Extract ZIP file to extract directory
        await executeCommand(
            `powershell -Command "Expand-Archive -Path '${zipFilePath}' -DestinationPath '${extractPath}' -Force"`
        );

        // Copy files from extract to deploy directory
        await executeCommand(
            `powershell -Command "Copy-Item -Path '${extractPath}\\*' -Destination '${deployPath}' -Recurse -Force"`
        );

        // Create wrangler.toml file in deploy directory
        const wranglerConfig = createWranglerConfig(subdomain);
        fs.writeFileSync(path.join(deployPath, 'wrangler.toml'), wranglerConfig);

        // Step 1: Create the project
        console.log('Creating Cloudflare Pages project...');
        await executeCommand(
            `npx wrangler pages project create ${projectName} --production-branch=main`,
            deployPath
        );

        // Step 2: Deploy the assets
        console.log('Deploying assets...');
        const { stdout } = await executeCommand(
            `npx wrangler pages deploy . --project-name=${projectName}`,
            deployPath
        );

        // Extract pages.dev URL
        const pagesDevUrl = stdout.match(/https:\/\/[^\s]+\.pages\.dev/)?.[0];
        if (!pagesDevUrl) {
            throw new Error('Could not find Pages URL in deployment output');
        }

        // Step 3: Create CNAME record
        console.log('Creating CNAME record...');
        await createCNAMERecord(subdomain, pagesDevUrl.replace('https://', ''));

        // Step 4: Attach custom domain to the project
        console.log('Attaching custom domain...');
        const customDomain = `${subdomain}.${MAIN_DOMAIN}`;
        await attachCustomDomain(projectName, customDomain);

        const customDomainUrl = `https://${customDomain}`;

        // Clean up
        try {
            fs.unlinkSync(zipFilePath);
            fs.rmSync(path.join(process.cwd(), 'uploads', projectName), { recursive: true, force: true });
        } catch (cleanupError) {
            console.error('Cleanup error:', cleanupError);
        }

        res.render('success', { 
            previewUrl: pagesDevUrl,
            customDomainUrl: customDomainUrl,
            subdomain: subdomain
        });
    } catch (error) {
        console.error('Deployment error:', error);
        
        // Attempt to clean up on error
        try {
            if (req.file && req.file.path) {
                fs.unlinkSync(req.file.path);
            }
            if (extractPath) {
                fs.rmSync(path.dirname(extractPath), { recursive: true, force: true });
            }
        } catch (cleanupError) {
            console.error('Cleanup error:', cleanupError);
        }

        res.status(500).render('error', { error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
}); 