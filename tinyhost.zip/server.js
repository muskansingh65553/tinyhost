const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(process.cwd(), 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, `site-${Date.now()}.zip`);
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/zip' || file.mimetype === 'application/x-zip-compressed') {
            cb(null, true);
        } else {
            cb(new Error('Only ZIP files are allowed!'), false);
        }
    }
});

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

// Helper function to execute commands
async function executeCommand(command, cwd = process.cwd()) {
    console.log(`Executing command: ${command}`);
    const { stdout, stderr } = await execPromise(command, { cwd });
    if (stderr) console.error('Command stderr:', stderr);
    console.log('Command stdout:', stdout);
    return { stdout, stderr };
}

// Routes
app.get('/', (req, res) => {
    res.render('index');
});

app.post('/deploy', upload.single('zipFile'), async (req, res) => {
    let extractPath;
    try {
        if (!req.file) {
            throw new Error('No file uploaded');
        }

        const projectName = `site-${Date.now()}`;
        const zipFilePath = req.file.path;
        extractPath = path.join(process.cwd(), 'uploads', projectName);

        // Create extraction directory
        if (!fs.existsSync(extractPath)) {
            fs.mkdirSync(extractPath, { recursive: true });
        }

        // Extract ZIP file
        await executeCommand(
            `powershell -Command "Expand-Archive -Path '${zipFilePath}' -DestinationPath '${extractPath}' -Force"`
        );

        // Step 1: Create the project
        console.log('Creating Cloudflare Pages project...');
        await executeCommand(
            `npx wrangler pages project create ${projectName} --production-branch=main`,
            extractPath
        );

        // Step 2: Deploy the assets
        console.log('Deploying assets...');
        const { stdout } = await executeCommand(
            `npx wrangler pages deploy . --project-name=${projectName}`,
            extractPath
        );

        // Extract the URL from deployment output
        const urlMatch = stdout.match(/https:\/\/[^\s]+\.pages\.dev/);
        const previewUrl = urlMatch ? urlMatch[0] : `https://${projectName}.pages.dev`;

        // Clean up
        try {
            fs.unlinkSync(zipFilePath);
            fs.rmSync(extractPath, { recursive: true, force: true });
        } catch (cleanupError) {
            console.error('Cleanup error:', cleanupError);
        }

        res.render('success', { previewUrl });
    } catch (error) {
        console.error('Deployment error:', error);
        
        // Attempt to clean up on error
        try {
            if (req.file && req.file.path) {
                fs.unlinkSync(req.file.path);
            }
            if (extractPath) {
                fs.rmSync(extractPath, { recursive: true, force: true });
            }
        } catch (cleanupError) {
            console.error('Cleanup error:', cleanupError);
        }

        // Check if it's a project creation error and try direct deployment
        if (error.message.includes('project create')) {
            try {
                console.log('Project creation failed, attempting direct deployment...');
                const { stdout } = await executeCommand(
                    `npx wrangler pages deploy . --project-name=${projectName}`,
                    extractPath
                );
                
                const urlMatch = stdout.match(/https:\/\/[^\s]+\.pages\.dev/);
                const previewUrl = urlMatch ? urlMatch[0] : `https://${projectName}.pages.dev`;
                
                return res.render('success', { previewUrl });
            } catch (deployError) {
                console.error('Direct deployment error:', deployError);
                return res.status(500).render('error', { 
                    error: 'Deployment failed. Please try again or contact support.' 
                });
            }
        }

        res.status(500).render('error', { error: error.message });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
}); 